package com.safeanchor;

/** Lưới 15x15 cho tâm tự vẽ: chuỗi 225 ký tự '0'/'1'. */
public final class CrossPix {
    public static final int N = 15;

    public static String blank() { return "0".repeat(N * N); }

    public static String plus() {
        char[] c = blank().toCharArray();
        for (int i = 0; i < N; i++) if (Math.abs(i - 7) > 1) { c[7 * N + i] = '1'; c[i * N + 7] = '1'; }
        return new String(c);
    }
    public static String dot() {
        char[] c = blank().toCharArray();
        c[7 * N + 7] = '1';
        return new String(c);
    }
    public static String ring() {
        char[] c = blank().toCharArray();
        for (int y = 0; y < N; y++) for (int x = 0; x < N; x++)
            if (Math.abs(Math.hypot(x - 7, y - 7) - 5.0) < 0.6) c[y * N + x] = '1';
        return new String(c);
    }

    public static boolean on(String s, int x, int y) {
        if (s == null || s.length() != N * N || x < 0 || y < 0 || x >= N || y >= N) return false;
        return s.charAt(y * N + x) == '1';
    }
    public static String with(String s, int x, int y, boolean v) {
        if (s == null || s.length() != N * N) s = blank();
        if (x < 0 || y < 0 || x >= N || y >= N) return s;
        char[] c = s.toCharArray();
        c[y * N + x] = v ? '1' : '0';
        return new String(c);
    }
}
