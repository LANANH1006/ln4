package com.safeanchor;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;

/** Chunk đáng nghi: dưới lòng đất (cách mặt >= susDepth block) có nhiều block do người chơi đặt -> tô đỏ. */
public class SusChunk {
    public static final Map<Long, Integer> hot = new HashMap<>();
    static final Map<Long, Integer> lastScan = new HashMap<>();
    static final Set<Block> SUS = new HashSet<>();
    static final String[] KEYS = {"chest", "barrel", "shulker_box", "hopper", "dispenser", "dropper", "furnace", "smoker", "obsidian", "respawn_anchor",
            "glass", "lantern", "torch", "ladder", "_bed", "crafting_table", "anvil", "observer", "piston", "repeater", "comparator", "redstone",
            "planks", "concrete", "tnt", "door", "sign", "beacon", "enchanting_table", "brewing_stand"};
    static int tickN, round;

    static void build() {
        for (Block b : Registries.BLOCK) {
            String id = Registries.BLOCK.getId(b).getPath();
            if (id.contains("rail") || id.contains("cave_vines")) continue;
            for (String k : KEYS) if (id.contains(k)) { SUS.add(b); break; }
        }
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I;
        if (!c.susOn || mc.world == null || mc.player == null) { if (!hot.isEmpty()) hot.clear(); return; }
        if (SUS.isEmpty()) build();
        Mods.Cfg cc = Mods.cfg("chunk");
        tickN++;
        int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4, rad = 10, side = rad * 2 + 1;
        for (int tries = 0; tries < side * side; tries++) {
            round = (round + 1) % (side * side);
            int cx = pcx - rad + round % side, cz = pcz - rad + round / side;
            long key = ChunkPos.toLong(cx, cz);
            Integer last = lastScan.get(key);
            if (last != null && tickN - last < 400) continue;
            WorldChunk ch = mc.world.getChunkManager().getWorldChunk(cx, cz);
            if (ch == null) continue;
            lastScan.put(key, tickN);
            int[][] surf = new int[16][16];
            for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) surf[x][z] = ch.sampleHeightmap(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
            int count = 0;
            ChunkSection[] secs = ch.getSectionArray();
            for (int i = 0; i < secs.length; i++) {
                if (secs[i].isEmpty() || !secs[i].hasAny(st -> SUS.contains(st.getBlock()))) continue;
                int baseY = (ch.getBottomSectionCoord() + i) << 4;
                for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) {
                    int limit = surf[x][z] - c.susDepth;
                    for (int y = 0; y < 16 && baseY + y < limit; y++) {
                        if (baseY + y < cc.minY || baseY + y > cc.maxY) continue;      // Min/Max Y của Chunk Finder
                        if (SUS.contains(secs[i].getBlockState(x, y, z).getBlock())) count++;
                    }
                }
            }
            if (count >= c.susMin) hot.put(key, count); else hot.remove(key);
            break;
        }
    }
}
