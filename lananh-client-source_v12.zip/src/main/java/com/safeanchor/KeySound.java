package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.InputUtil;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import org.lwjgl.glfw.GLFW;

/** Âm bàn phím kiểu Creamy Keys: mỗi lần nhấn (và nhả, nếu bật) một phím / nút chuột là có tiếng "cạch". */
public class KeySound {
    static final boolean[] down = new boolean[350];
    static final boolean[] mdown = new boolean[3];

    static RegistryEntry<SoundEvent> sound(int type) {
        return switch (type) {
            case 1 -> SoundEvents.BLOCK_NOTE_BLOCK_HAT;
            case 2 -> SoundEvents.UI_BUTTON_CLICK;
            case 3 -> SoundEvents.BLOCK_NOTE_BLOCK_BIT;
            default -> SoundEvents.BLOCK_NOTE_BLOCK_BASEDRUM;
        };
    }

    static void play(MinecraftClient mc, int key, boolean release) {
        Config c = Config.I;
        float pitch = (float) (c.keySoundPitch / 100.0) * (0.94f + (float) Math.random() * 0.12f);
        if (key == GLFW.GLFW_KEY_SPACE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_BACKSPACE) pitch *= 0.78f;   // phím to nghe trầm hơn
        if (release) pitch *= 1.3f;
        pitch = Math.max(0.5f, Math.min(2.0f, pitch));
        mc.getSoundManager().play(PositionedSoundInstance.master(sound(c.keySoundType), pitch));
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I;
        if (!c.keySound || !c.enabled) return;
        long h = mc.getWindow().getHandle();
        for (int k = 32; k < 350; k++) {
            boolean d = InputUtil.isKeyPressed(h, k);
            if (d != down[k]) {
                down[k] = d;
                if (d) play(mc, k, false); else if (c.keySoundRelease) play(mc, k, true);
            }
        }
        for (int b = 0; b < 3; b++) {
            boolean d = GLFW.glfwGetMouseButton(h, b) == GLFW.GLFW_PRESS;
            if (d != mdown[b]) {
                mdown[b] = d;
                if (d) play(mc, 0, false); else if (c.keySoundRelease) play(mc, 0, true);
            }
        }
    }
}
